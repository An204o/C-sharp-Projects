﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Application_Project_for_Stock_Data
{
    /// <summary>
    /// This class is responsible for loading candlestick data from a CSV file.
    /// </summary>
    internal class StockLoader1
    {
        /// <summary>
        /// Loads candlestick data from a CSV file and returns a list of Candlestick objects.
        /// </summary>
        public static List<Candlestick1> Load(string filePath)
        {
            // List used to store all candlestick objects
            List<Candlestick1> candlesticks = new List<Candlestick1>();

            // Open the file for reading
            using (StreamReader reader = new StreamReader(filePath))
            {
                // Skip the header line
                reader.ReadLine();

                // Read each line until the end of the file
                while (!reader.EndOfStream)
                {
                    // Read one line from the file
                    string line = reader.ReadLine();

                    // Ensure the line is not empty
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        // Create a Candlestick object from the CSV line
                        Candlestick1 candle = new Candlestick1(line);

                        // Add the object to the list
                        candlesticks.Add(candle);
                    }
                }
            }

            // Return the completed list
            return candlesticks;
        }
    }
}