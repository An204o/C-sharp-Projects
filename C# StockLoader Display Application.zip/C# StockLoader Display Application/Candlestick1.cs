﻿using System;

namespace Application_Project_for_Stock_Data
{
    /// <summary>
    /// Represents a single candlestick record from the stock CSV file.
    /// </summary>
    internal class Candlestick1
    {
        // Properties for stock data
        public DateTime Date { get; set; }
        public decimal Open { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Close { get; set; }
        public ulong Volume { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public Candlestick1()
        {
        }

        /// <summary>
        /// Constructor with parameters
        /// </summary>
        public Candlestick1(DateTime date, decimal open, decimal high, decimal low, decimal close, ulong volume)
        {
            Date = date;
            Open = open;
            High = high;
            Low = low;
            Close = close;
            Volume = volume;
        }

        /// <summary>
        /// Copy constructor
        /// </summary>
        public Candlestick1(Candlestick1 sourceCandlestick)
        {
            Date = sourceCandlestick.Date;
            Open = sourceCandlestick.Open;
            High = sourceCandlestick.High;
            Low = sourceCandlestick.Low;
            Close = sourceCandlestick.Close;
            Volume = sourceCandlestick.Volume;
        }

        /// <summary>
        /// Constructor that creates a Candlestick object from a CSV line
        /// </summary>
        public Candlestick1(string csvLine)
        {
            // Split the CSV line into values
            string[] values = csvLine.Split(',');

            // Convert values into appropriate data types
            Date = DateTime.Parse(values[0].Trim('"'));
            Open = decimal.Parse(values[1]);
            High = decimal.Parse(values[2]);
            Low = decimal.Parse(values[3]);
            Close = decimal.Parse(values[4]);
            Volume = ulong.Parse(values[5]);
        }
    }
}