﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Application_Project_for_Stock_Data
{
    public partial class Form1 : Form
    {
        // List that stores all loaded candlesticks
        private List<Candlestick1> allCandlesticks = new List<Candlestick1>();

        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Runs when the form loads
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            // Set default dates required by the assignment
            dateTimePicker1.Value = new DateTime(2021, 1, 28);
            dateTimePicker2.Value = new DateTime(2021, 2, 28);

            // Fill the period combo box
            comboBox1.Items.Add("All");
            comboBox1.Items.Add("Daily");
            comboBox1.Items.Add("Weekly");
            comboBox1.Items.Add("Monthly");
            comboBox1.Items.Add("Yearly");

            comboBox1.SelectedIndex = 0;
        }

        /// <summary>
        /// Load Stock button
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;

                // Load CSV data
                allCandlesticks = StockLoader1.Load(filePath);

                DisplayFilteredData();
            }
        }

        /// <summary>
        /// Update button
        /// </summary>
        private void button2_Click(object sender, EventArgs e)
        {
            DisplayFilteredData();
        }

        /// <summary>
        /// Filters data based on selected date range
        /// </summary>
        private void DisplayFilteredData()
        {
            DateTime startDate = dateTimePicker1.Value.Date;
            DateTime endDate = dateTimePicker2.Value.Date;

            if (endDate < startDate)
            {
                MessageBox.Show("End date must be after start date.");
                return;
            }

            var filtered = allCandlesticks
                .Where(c => c.Date >= startDate && c.Date <= endDate)
                .OrderBy(c => c.Date)
                .ToList();

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = filtered;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = comboBox1.SelectedItem.ToString();

            if (selected == "Daily")
                openFileDialog1.Filter = "*-daily.csv|*-daily.csv";
            else if (selected == "Weekly")
                openFileDialog1.Filter = "*-weekly.csv|*-weekly.csv";
            else if (selected == "Monthly")
                openFileDialog1.Filter = "*-monthly.csv|*-monthly.csv";
            else if (selected == "Yearly")
                openFileDialog1.Filter = "*-yearly.csv|*-yearly.csv";
            else
                openFileDialog1.Filter = "*.csv|*.csv";
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e) { }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e) { }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e) { }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}