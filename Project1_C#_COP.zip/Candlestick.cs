﻿using System;

namespace PR1_C_
{
    /// <summary>
    /// This represents single stock record candlestic
    /// </summary>
    internal class Candlestick
    {
        // Properties of the candlestick
        public DateTime Date { get; set; }
        public decimal Open { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Close { get; set; }
        public ulong Volume { get; set; }
        //This is the default constructor
        public Candlestick()
        {
        }
        /// <summary>
        ////This is the constructor with parameters
        /// </summary>
        public Candlestick(DateTime date, decimal open, decimal high, decimal low, decimal close, ulong volume)
        {
            Date = date;
            Open = open;
            High = high;
            Low = low;
            Close = close;
            Volume = volume;
        }
        /// <summary>
        /// This is the constructor that duplicates the constructor
        /// </summary>
        public Candlestick(Candlestick sourceCandlestick)
        {
            Date = sourceCandlestick.Date;
            Open = sourceCandlestick.Open;
            High = sourceCandlestick.High;
            Low = sourceCandlestick.Low;
            Close = sourceCandlestick.Close;
            Volume = sourceCandlestick.Volume;
        }
        /// <summary>
        /// This 
        /// </summary>
        public Candlestick(string csvLine)
        {
            //This splits the one line from the csv line with comma
            string[] values = csvLine.Split(',');

            //This converst the values to the approriate particular data types
            Date = DateTime.Parse(values[0].Trim('"'));
            Open = decimal.Parse(values[1]);
            High = decimal.Parse(values[2]);
            Low = decimal.Parse(values[3]);
            Close = decimal.Parse(values[4]);
            Volume = ulong.Parse(values[5]);
        }
    }
}