﻿namespace PR1_C_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button_LoadStock = new System.Windows.Forms.Button();
            this.Button_Update = new System.Windows.Forms.Button();
            this.DataGridView_Stock = new System.Windows.Forms.DataGridView();
            this.DateTimePicker_End = new System.Windows.Forms.DateTimePicker();
            this.DateTimePicker_Start = new System.Windows.Forms.DateTimePicker();
            this.ComboBox_Period = new System.Windows.Forms.ComboBox();
            this.OpenFileDialog_LoadStock = new System.Windows.Forms.OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_Stock)).BeginInit();
            this.SuspendLayout();
            // 
            // Button_LoadStock
            // 
            this.Button_LoadStock.Location = new System.Drawing.Point(12, 351);
            this.Button_LoadStock.Name = "Button_LoadStock";
            this.Button_LoadStock.Size = new System.Drawing.Size(141, 57);
            this.Button_LoadStock.TabIndex = 0;
            this.Button_LoadStock.Text = "Load Stock";
            this.Button_LoadStock.UseVisualStyleBackColor = true;
            this.Button_LoadStock.Click += new System.EventHandler(this.Button_LoadStock_Click);
            // 
            // Button_Update
            // 
            this.Button_Update.Location = new System.Drawing.Point(159, 347);
            this.Button_Update.Name = "Button_Update";
            this.Button_Update.Size = new System.Drawing.Size(145, 61);
            this.Button_Update.TabIndex = 1;
            this.Button_Update.Text = "Update";
            this.Button_Update.UseVisualStyleBackColor = true;
            this.Button_Update.Click += new System.EventHandler(this.Button_Update_Click);
            // 
            // DataGridView_Stock
            // 
            this.DataGridView_Stock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView_Stock.Location = new System.Drawing.Point(89, 71);
            this.DataGridView_Stock.Name = "DataGridView_Stock";
            this.DataGridView_Stock.RowHeadersWidth = 82;
            this.DataGridView_Stock.RowTemplate.Height = 33;
            this.DataGridView_Stock.Size = new System.Drawing.Size(665, 250);
            this.DataGridView_Stock.TabIndex = 2;
            this.DataGridView_Stock.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_Stock_CellContentClick);
            // 
            // DateTimePicker_End
            // 
            this.DateTimePicker_End.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePicker_End.Location = new System.Drawing.Point(337, 384);
            this.DateTimePicker_End.Name = "DateTimePicker_End";
            this.DateTimePicker_End.Size = new System.Drawing.Size(363, 31);
            this.DateTimePicker_End.TabIndex = 3;
            this.DateTimePicker_End.ValueChanged += new System.EventHandler(this.DateTimePicker_End_ValueChanged);
            // 
            // DateTimePicker_Start
            // 
            this.DateTimePicker_Start.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateTimePicker_Start.Location = new System.Drawing.Point(337, 347);
            this.DateTimePicker_Start.Name = "DateTimePicker_Start";
            this.DateTimePicker_Start.Size = new System.Drawing.Size(363, 31);
            this.DateTimePicker_Start.TabIndex = 4;
            this.DateTimePicker_Start.ValueChanged += new System.EventHandler(this.DateTimePicker_Start_ValueChanged);
            // 
            // ComboBox_Period
            // 
            this.ComboBox_Period.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_Period.FormattingEnabled = true;
            this.ComboBox_Period.Location = new System.Drawing.Point(727, 347);
            this.ComboBox_Period.Name = "ComboBox_Period";
            this.ComboBox_Period.Size = new System.Drawing.Size(164, 33);
            this.ComboBox_Period.TabIndex = 5;
            this.ComboBox_Period.SelectedIndexChanged += new System.EventHandler(this.ComboBox_Period_SelectedIndexChanged);
            // 
            // OpenFileDialog_LoadStock
            // 
            this.OpenFileDialog_LoadStock.FileName = "ABBV_daily.csv";
            this.OpenFileDialog_LoadStock.Filter = "All|*.csv|Yearly|*_Yearly.csv|Monthly|*_Monthly.csv|Weekly|*_Weekly.csv|Daily|*_D" +
    "aily.csv";
            this.OpenFileDialog_LoadStock.FilterIndex = 5;
            this.OpenFileDialog_LoadStock.InitialDirectory = "C:\\Users\\yagon\\.ms-ad\\Downloads\\P1 C#\\Stock Data";
            this.OpenFileDialog_LoadStock.ReadOnlyChecked = true;
            this.OpenFileDialog_LoadStock.ShowReadOnly = true;
            this.OpenFileDialog_LoadStock.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog_Stock_FileOk);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(979, 490);
            this.Controls.Add(this.ComboBox_Period);
            this.Controls.Add(this.DateTimePicker_Start);
            this.Controls.Add(this.DateTimePicker_End);
            this.Controls.Add(this.DataGridView_Stock);
            this.Controls.Add(this.Button_Update);
            this.Controls.Add(this.Button_LoadStock);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_Stock)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Button_LoadStock;
        private System.Windows.Forms.Button Button_Update;
        private System.Windows.Forms.DataGridView DataGridView_Stock;
        private System.Windows.Forms.DateTimePicker DateTimePicker_End;
        private System.Windows.Forms.DateTimePicker DateTimePicker_Start;
        private System.Windows.Forms.ComboBox ComboBox_Period;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog_LoadStock;
    }
}

