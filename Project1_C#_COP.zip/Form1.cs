﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace PR1_C_
{
    /// <summary>
    /// Main form for loading and displaying stock data.
    /// </summary>
    public partial class Form1 : Form
    {
        // Stores all loaded candlestick data
        private List<Candlestick> allCandlesticks = new List<Candlestick>();
        /// <summary>
        /// This will start the form
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Sets default values when the form loads.
        /// </summary>
        private void Form1_Load(object sender, EventArgs e)
        {
            //This is setting teh values into a particular time range
            DateTimePicker_Start.Value = new DateTime(2021, 1, 28);
            DateTimePicker_End.Value = new DateTime(2021, 2, 28);
            //This is adding the items into the combo box
            ComboBox_Period.Items.Clear();
            ComboBox_Period.Items.Add("All");
            ComboBox_Period.Items.Add("Daily");
            ComboBox_Period.Items.Add("Weekly");
            ComboBox_Period.Items.Add("Monthly");
            ComboBox_Period.Items.Add("Yearly");
            ComboBox_Period.SelectedIndex = 0;
            //This sets the filter for open files
            OpenFileDialog_LoadStock.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            OpenFileDialog_LoadStock.Title = "Select a stock CSV file";
            //This provides or sets the default folder/file for loading the stock data
            string defaultFolder = Path.Combine(Application.StartupPath, @"..\..\..\Stock Data");
            if (Directory.Exists(defaultFolder))
            {

                OpenFileDialog_LoadStock.InitialDirectory = Path.GetFullPath(defaultFolder);

                string defaultFile = Path.Combine(Path.GetFullPath(defaultFolder), "ABBV-daily.csv");
                if (File.Exists(defaultFile))
                {
                    OpenFileDialog_LoadStock.FileName = defaultFile;
                }
            }
        }
        /// <summary>
        /// This will load stock data from the selected CSV file.
        /// </summary>
        private void Button_LoadStock_Click(object sender, EventArgs e)
        {
            //This will open the file dialog to select a CSV file
            if (OpenFileDialog_LoadStock.ShowDialog() == DialogResult.OK)
            {

                string filePath = OpenFileDialog_LoadStock.FileName;
                allCandlesticks = StockDataLoader.Load(filePath);
                DisplayFilteredData();
            }
        }
        /// <summary>
        /// Updates the displayed stock data using the selected date range.
        /// </summary>
        private void Button_Update_Click(object sender, EventArgs e)
        {
            DisplayFilteredData();
        }
        /// <summary>
        /// Filters the stock data by date and shows it in the DataGridView.
        /// </summary>
        private void DisplayFilteredData()
        {
            //This will get the start and end dates from the date pickers
            DateTime startDate = DateTimePicker_Start.Value.Date;
            DateTime endDate = DateTimePicker_End.Value.Date;

            //This checks if the end date is before the start date and shows a message if it is
            if (endDate < startDate)
            {
                MessageBox.Show("End date must be after start date.");
                return;
            }
            //This filters the loaded candlestick data based on the selected date range and sorts it by date
            var filteredData = allCandlesticks
                .Where(c => c.Date.Date >= startDate && c.Date.Date <= endDate)
                .OrderBy(c => c.Date)
                .ToList();

            DataGridView_Stock.DataSource = null;
            DataGridView_Stock.DataSource = filteredData;
        }
        /// <summary>
        /// This handles changes to the start date picker.
        /// </summary>
        private void DateTimePicker_Start_ValueChanged(object sender, EventArgs e)
        {
        }
        /// <summary>
        /// This handles changes to the end date picker.
        /// </summary>
        private void DateTimePicker_End_ValueChanged(object sender, EventArgs e)
        {
        }
        /// <summary>
        /// This changes the file filter based on the selected stock period.
        /// </summary>
        private void ComboBox_Period_SelectedIndexChanged(object sender, EventArgs e)
        {
            //This will get the selected period from the combo box
            string selectedPeriod = ComboBox_Period.SelectedItem.ToString();
            //This is used for changing the file dialog filter based on the selected value/period
            if (selectedPeriod == "Daily")
            {
                OpenFileDialog_LoadStock.Filter = "Daily CSV files (*-daily.csv)|*-daily.csv|CSV files (*.csv)|*.csv";
            }
            else if (selectedPeriod == "Weekly")
            {
                OpenFileDialog_LoadStock.Filter = "Weekly CSV files (*-weekly.csv)|*-weekly.csv|CSV files (*.csv)|*.csv";
            }
            else if (selectedPeriod == "Monthly")
            {
                OpenFileDialog_LoadStock.Filter = "Monthly CSV files (*-monthly.csv)|*-monthly.csv|CSV files (*.csv)|*.csv";
            }
            else if (selectedPeriod == "Yearly")
            {
                OpenFileDialog_LoadStock.Filter = "Yearly CSV files (*-yearly.csv)|*-yearly.csv|CSV files (*.csv)|*.csv";
            }
            else
            {
                OpenFileDialog_LoadStock.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
            }
        }
        // <summary>
        /// This handles clicks inside the DataGridView.
        /// </summary>
        private void DataGridView_Stock_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        /// <summary>
        /// This handles the file dialog confirmation event.
        /// </summary>
        private void OpenFileDialog_Stock_FileOk(object sender, CancelEventArgs e)
        {
        }
    }
}