﻿//Anar Mammadli
//U#: U06454311
using System.Collections.Generic;
using System.IO;


namespace PR1_C_
{
    internal class StockDataLoader
    {
        /// <summary>
        /// This loads candlestick data from a CSV file
        /// </summary>
        public static List<Candlestick> Load(string filePath)
        {
            // This is the list for storing all candlestick objects
            List<Candlestick> candlesticks = new List<Candlestick>();
            //Opens the file while reading
            using (StreamReader reader = new StreamReader(filePath))
            {
               
                reader.ReadLine();
                //This reads each line
                while (!reader.EndOfStream)
                {
                    //Read one line from the file
                    string line = reader.ReadLine();
                    //This checks if the the lien is not empty
                    if (!string.IsNullOrWhiteSpace(line))
                    {
                        //This is creating a Candlestick object, particularly from CSV line
                        Candlestick candle = new Candlestick(line);
                        //This adds the created object to the list
                        candlesticks.Add(candle);
                    }
                }
            }
            //Finally, this will return the list of those added objects
            return candlesticks;
        }
    }
}